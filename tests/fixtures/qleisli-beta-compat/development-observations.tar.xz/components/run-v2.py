from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tomllib
base=Path(__file__).parent;root=Path('/Users/masa/git/qargo');ql=Path('/Users/masa/git/Qleisli');sys.path.insert(0,str(ql/'scripts'));from ci_source_checks import snapshot
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((base/'PLAN-v2.json').read_bytes());assert not (base/'started-v2.json').exists()
kernel=ql/'lean-kernel/.lake/build/bin/qleisli-kernel'
def inventory():
 names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).split(b'\0');files={}
 for name in sorted(set(names)-{b''}):
  label=os.fsdecode(name);p=root/label;files[label]={'link':os.readlink(p)} if p.is_symlink() else {'sha256':sha(p),'mode':p.stat().st_mode&0o777} if p.is_file() else {'missing':True}
 return files
before={'qargo_files':inventory(),'qleisli':snapshot(ql),'kernel_sha256':sha(kernel)};report={'scope':plan['scope'],'plan_sha256':sha(base/'PLAN-v2.json'),'driver_sha256':sha(Path(__file__)),'before':before,'pid':os.getpid(),'pgid':os.getpgrp(),'commands':[],'lock_transitions':{}};(base/'started-v2.json').write_text(json.dumps(report,indent=2)+'\n');start=time.monotonic()
for label in plan['allowed_source_changes']:
 p=base/'before'/label;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/label).read_bytes())
def environment(kind):
 directory=Path('/opt/homebrew/bin') if kind=='normal' else Path('/Users/masa/.rustup/toolchains/1.85.0-aarch64-apple-darwin/bin');version='1.98.1' if kind=='normal' else '1.85.0';env=dict(os.environ)
 for key in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:env.pop(key,None)
 tools={}
 for n in ['cargo','rustc','rustdoc','cargo-clippy','clippy-driver']:
  p=directory/n;v=subprocess.check_output([str(p),'--version'],text=True).strip();tools[n]={'path':str(p),'version':v,'sha256':sha(p)}
  if n in ['cargo','rustc','rustdoc']:assert v.startswith(n+' '+version+' ')
 env.update(RUSTC=str(directory/'rustc'),RUSTDOC=str(directory/'rustdoc'),RUSTUP_TOOLCHAIN=version,PATH=str(directory)+os.pathsep+os.environ.get('PATH',''),CARGO_TARGET_DIR=str(ql/'target'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',QLEISLI_KERNEL=str(kernel));return directory/'cargo',env,tools

def run(label,kind,args):
 cargo,env,tools=environment(kind);argv=[str(cargo),args[0],'--config','patch.crates-io.qleisli.path="/Users/masa/git/Qleisli"',*args[1:]];row={'label':label,'toolchain':kind,'argv':argv,'tools':tools,'environment':{n:env[n] for n in ['RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN','PATH','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','QLEISLI_KERNEL']}};(base/(label+'.started.json')).write_text(json.dumps(row,indent=2)+'\n');t=time.monotonic()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:done=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=err)
 row.update(exit_code=done.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(base/(label+'.stdout')),stderr_sha256=sha(base/(label+'.stderr')));report['commands'].append(row);(base/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['label','exit_code','seconds']}),flush=True);return done.returncode
try:
 for name in plan['components']:
  manifest='rust/'+name+'/Cargo.toml';label=name+'-metadata';assert run(label,'normal',['metadata','--offline','--manifest-path',manifest,'--format-version=1'])==0
  lock='rust/'+name+'/Cargo.lock';old=tomllib.loads((base/'before'/lock).read_text());new=tomllib.loads((root/lock).read_text());old_packages={(p['name'],p['version']):p for p in old['package'] if p['name']!='qleisli'};new_packages={(p['name'],p['version']):p for p in new['package'] if p['name']!='qleisli'};assert all(new_packages.get(k)==v for k,v in old_packages.items());added=[v for k,v in new_packages.items() if k not in old_packages];main_packages={(p['name'],p['version']):p for p in tomllib.loads((root/'Cargo.lock').read_text())['package']};assert all(v['name'] in ['equivalent','hashbrown','indexmap','serde_spanned','toml','toml_datetime','toml_edit','toml_write','winnow'] and {k:x for k,x in v.items() if k!='dependencies'}=={k:x for k,x in main_packages[(v['name'],v['version'])].items() if k!='dependencies'} and set(v.get('dependencies',[]))<=set(main_packages[(v['name'],v['version'])].get('dependencies',[])) for v in added);assert [p for p in new['package'] if p['name']=='qleisli']==[{'name':'qleisli','version':'0.3.0-beta','dependencies':['rustix','toml']}]
  metadata=json.loads((base/(label+'.stdout')).read_bytes());dep=[p for p in metadata['packages'] if p['name']=='qleisli'];assert len(dep)==1 and dep[0]['version']=='0.3.0-beta' and dep[0]['source'] is None and Path(dep[0]['manifest_path']).resolve()==ql/'Cargo.toml'
  p=base/'after'/lock;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/lock).read_bytes());report['lock_transitions'][lock]={'before_sha256':sha(base/'before'/lock),'after_sha256':sha(root/lock),'existing_non_qleisli_packages_unchanged':len(old_packages),'new_required_toml_packages':added}
  for kind in ['normal','msrv']:
   run(name+'-'+kind+'-tests',kind,['test','--offline','--locked','--manifest-path',manifest,'--all-targets','--no-fail-fast'])
   run(name+'-'+kind+'-clippy',kind,['clippy','--offline','--locked','--manifest-path',manifest,'--all-targets','--','-D','warnings'])
except BaseException as err:
 report['exception']=type(err).__name__+': '+str(err)
finally:
 after={'qargo_files':inventory(),'qleisli':snapshot(ql),'kernel_sha256':sha(kernel)};changes=sorted(k for k in set(before['qargo_files'])|set(after['qargo_files']) if before['qargo_files'].get(k)!=after['qargo_files'].get(k));stable=before['qleisli']==after['qleisli'] and before['kernel_sha256']==after['kernel_sha256'] and set(changes)<=set(plan['allowed_source_changes']);report.update(after=after,source_changes=changes,stable_except_authorized_lock_transitions=stable,seconds=time.monotonic()-start);report['status']='passed' if stable and len(report['commands'])==15 and all(r['exit_code']==0 for r in report['commands']) and 'exception' not in report else 'failed';(base/'report-v2.json').write_text(json.dumps(report,indent=2)+'\n')
print('REPORT '+str(base/'report-v2.json'),flush=True);raise SystemExit(0 if report['status']=='passed' else 1)
