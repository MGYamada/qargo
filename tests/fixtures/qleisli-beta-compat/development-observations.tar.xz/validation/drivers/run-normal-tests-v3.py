from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path(__file__).parent;root=Path('/Users/masa/git/qargo');ql=Path('/Users/masa/git/Qleisli')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap(repo):
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=repo).decode().strip('\0').split('\0')
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{n:sha(repo/n) for n in sorted(set(names)) if n and (repo/n).is_file()}}
label='normal-tests-v3';startfile=base/(label+'.started.json');reportfile=base/(label+'.json');assert not startfile.exists() and not reportfile.exists()
tools={n:Path('/opt/homebrew/bin')/n for n in ['cargo','rustc','rustdoc']}
versions={n:{'path':str(p),'sha256':sha(p),'version':subprocess.check_output([str(p),'--version'],text=True).strip()} for n,p in tools.items()}
env=dict(os.environ,RUSTC=str(tools['rustc']),RUSTDOC=str(tools['rustdoc']),CARGO_TARGET_DIR=str(ql/'target'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',QLEISLI_KERNEL=str(ql/'lean-kernel/.lake/build/bin/qleisli-kernel'))
argv=[str(tools['cargo']),'--config','patch.crates-io.qleisli.path="/Users/masa/git/Qleisli"','test','--offline','--locked','--workspace','--all-targets','--no-fail-fast']
before=snap(root);qlbefore=snap(ql);lock=(root/'Cargo.lock').read_bytes();(base/'normal-tests-v3-start.Cargo.lock').write_bytes(lock)
meta={'scope':'Explicit development local-link to unpublished Qleisli beta/J; not registry resolution, package/install readiness or binary attestation. This is an actual test invocation with explicit existing native selection; skip/results are reported from terminal logs. The already resolved development lock is required unchanged. One existing shared target, no new cache/target/checkout.','argv':argv,'cwd':str(root),'tools':versions,'environment':{k:env[k] for k in ['RUSTC','RUSTDOC','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','QLEISLI_KERNEL']},'qargo_before':before,'qleisli_before':qlbefore,'kernel_before':sha(Path(env['QLEISLI_KERNEL'])),'driver_sha256':sha(Path(__file__)),'pid':os.getpid(),'pgid':os.getpgrp()}
startfile.write_text(json.dumps(meta,indent=2)+'\n');start=time.monotonic()
with (base/(label+'.stdout')).open('xb') as stdout,(base/(label+'.stderr')).open('xb') as stderr:
 try:
  done=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
 except KeyboardInterrupt:
  done=subprocess.CompletedProcess(argv,130)
after=snap(root);qlafter=snap(ql);changed=[n for n in set(before['files'])|set(after['files']) if before['files'].get(n)!=after['files'].get(n)]
(base/'normal-tests-v3-end.Cargo.lock').write_bytes((root/'Cargo.lock').read_bytes())
report=meta|{'exit_code':done.returncode,'seconds':time.monotonic()-start,'qargo_after':after,'qleisli_after':qlafter,'qargo_changed':sorted(changed),'qargo_source_stable_except_owned_development_lock':before['head']==after['head'] and not changed,'qleisli_stable':qlbefore==qlafter,'kernel_stable':meta['kernel_before']==sha(Path(env['QLEISLI_KERNEL']))}
reportfile.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['exit_code','seconds','qargo_changed','qargo_source_stable_except_owned_development_lock','qleisli_stable','kernel_stable']}),flush=True)
print((base/(label+'.stderr')).read_text(errors='replace')[-9000:],flush=True)
print('REPORT '+str(reportfile),flush=True)
raise SystemExit(done.returncode if report['qargo_source_stable_except_owned_development_lock'] and report['qleisli_stable'] and report['kernel_stable'] else 99)
