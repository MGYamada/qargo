from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path(__file__).parent;ql=Path('/Users/masa/git/Qleisli');qargo=Path('/Users/masa/git/qargo');sys.path.insert(0,str(ql/'scripts'))
from ci_source_checks import snapshot
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
label='runtime-verifier-v1';startfile=base/(label+'.started.json');reportfile=base/(label+'.json');assert not startfile.exists() and not reportfile.exists()
binaries={name:ql/'bin'/name for name in ['qargo','qlippy','qlifmt','qlidoc']};kernel=ql/'lean-kernel/.lake/build/bin/qleisli-kernel';verifier=qargo/'scripts/verify_release.py';assert sha(verifier)=='1996d10969066df73956409cc2578486dcf14096081af915dfecf73efc8e5f49'
meta={'scope':'Actual development runtime/source comparison using requested Qleisli/bin four-binary placement, explicit locally linked Qleisli sources and selected native checker. Not registry resolution, official archive/installer readiness, binary-source attestation or release approval.','argv':[sys.executable,'-B',str(verifier),'--source-root='+str(qargo),'--bin-dir='+str(ql/'bin'),'--qleisli-source-root='+str(ql)],'python':{'path':sys.executable,'version':sys.version},'qargo_before':snapshot(qargo),'qleisli_before':snapshot(ql),'binaries_before':{n:sha(p) for n,p in binaries.items()},'kernel_before':sha(kernel),'verifier_sha256':sha(verifier),'driver_sha256':sha(Path(__file__)),'pid':os.getpid(),'pgid':os.getpgrp()};env=dict(os.environ,QLEISLI_KERNEL=str(kernel),PYTHONDONTWRITEBYTECODE='1');meta['QLEISLI_KERNEL']=str(kernel);startfile.write_text(json.dumps(meta,indent=2)+'\n');start=time.monotonic()
with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:
 try:done=subprocess.run(meta['argv'],cwd=qargo,env=env,stdout=out,stderr=err)
 except KeyboardInterrupt:done=subprocess.CompletedProcess(meta['argv'],130)
report=meta|{'exit_code':done.returncode,'seconds':time.monotonic()-start,'qargo_after':snapshot(qargo),'qleisli_after':snapshot(ql),'binaries_after':{n:sha(p) for n,p in binaries.items()},'kernel_after':sha(kernel)};report['source_stable']=report['qargo_before']==report['qargo_after'] and report['qleisli_before']==report['qleisli_after'];report['binaries_stable']=report['binaries_before']==report['binaries_after'] and report['kernel_before']==report['kernel_after'];reportfile.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
for suffix in ['stdout','stderr']:print(suffix+':\n'+(base/(label+'.'+suffix)).read_text(errors='replace')[-7000:],flush=True)
raise SystemExit(done.returncode if report['source_stable'] and report['binaries_stable'] else 99)
