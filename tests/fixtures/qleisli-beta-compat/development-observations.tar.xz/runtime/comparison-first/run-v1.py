from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path(__file__).parent;root=Path('/Users/masa/git/qargo');ql=Path('/Users/masa/git/Qleisli');sys.path.insert(0,str(ql/'scripts'));from ci_source_checks import snapshot
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();kernel=ql/'lean-kernel/.lake/build/bin/qleisli-kernel';binaries=[ql/'target/debug'/n for n in ['qlippy','qlifmt','qlidoc']]+[ql/'bin'/n for n in ['qargo','qlippy','qlifmt','qlidoc']]
def inputs():return {'qargo':snapshot(root),'qleisli':snapshot(ql),'kernel_sha256':sha(kernel),'binaries':{str(p):sha(p) for p in binaries},'verifier_sha256':sha(root/'scripts/verify_qrate.py')}
report={'scope':'Actual standalone/bundle CLI comparisons using explicit copied development tools and already built native checker; not isolated extraction, registry/package/installer readiness, compiler/source attestation or proofs','driver_sha256':sha(Path(__file__)),'before':inputs(),'commands':[],'pid':os.getpid(),'pgid':os.getpgrp()};assert not (base/'started-v1.json').exists();(base/'started-v1.json').write_text(json.dumps(report,indent=2)+'\n');env=dict(os.environ);env.update(QLEISLI_KERNEL=str(kernel),PYTHONDONTWRITEBYTECODE='1');start=time.monotonic()
try:
 argv=[sys.executable,'-B','-m','unittest','test_install','test_distribution','test_qleisli_dependency','test_verify_release','test_qrate_project'];t=time.monotonic()
 with (base/'host-tests.stdout').open('xb') as out,(base/'host-tests.stderr').open('xb') as err:done=subprocess.run(argv,cwd=root/'scripts',env=env,stdout=out,stderr=err)
 report['commands'].append({'label':'host-tests','argv':argv,'exit_code':done.returncode,'seconds':time.monotonic()-t,'stdout_sha256':sha(base/'host-tests.stdout'),'stderr_sha256':sha(base/'host-tests.stderr')});print(json.dumps(report['commands'][-1]),flush=True)
 sys.path.insert(0,str(root/'scripts'));import verify_qrate
 real_run=subprocess.run;invocations=[];records=base/'invocations';records.mkdir();work=base/'runtime';work.mkdir()
 def observe(command,**kwargs):
  index=len(invocations);cwd=Path(kwargs['cwd']);sources={str(p.relative_to(cwd)):p.read_text() for p in [cwd/'Qargo.toml',cwd/'src/smoke.qli'] if p.exists()};t=time.monotonic();result=real_run(command,**kwargs);prefix=records/f'{index:04d}';stdout=Path(str(prefix)+'.stdout');stderr=Path(str(prefix)+'.stderr');stdout.write_bytes(result.stdout);stderr.write_bytes(result.stderr);row={'argv':command,'cwd':str(cwd),'sources':sources,'QLEISLI_KERNEL':kwargs['env']['QLEISLI_KERNEL'],'exit_code':result.returncode,'seconds':time.monotonic()-t,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)};Path(str(prefix)+'.json').write_text(json.dumps(row,indent=2)+'\n');invocations.append(row);return result
 verify_qrate.subprocess.run=observe
 try:
  for name in ['qlippy','qlifmt','qlidoc']:
   directory=work/name;directory.mkdir();before=len(invocations);t=time.monotonic();verify_qrate.compare_entrypoints(name,ql/'target/debug'/name,ql/'bin'/name,directory,env);row={'label':name+'-actual-cli-comparisons','exit_code':0,'invocations':len(invocations)-before,'comparisons':(len(invocations)-before)//2,'seconds':time.monotonic()-t};report['commands'].append(row);print(json.dumps(row),flush=True)
 finally:
  verify_qrate.subprocess.run=real_run;(base/'invocations.json').write_text(json.dumps(invocations,indent=2)+'\n');report['direct_tool_invocations']=len(invocations)
except BaseException as err:report['exception']=type(err).__name__+': '+str(err)
finally:
 report.update(after=inputs(),seconds=time.monotonic()-start);report['stable']=report['before']==report['after'];report['status']='passed' if report['stable'] and len(report['commands'])==4 and all(r['exit_code']==0 for r in report['commands']) and 'exception' not in report else 'failed';(base/'report-v1.json').write_text(json.dumps(report,indent=2)+'\n')
print('REPORT '+str(base/'report-v1.json'),flush=True);raise SystemExit(0 if report['status']=='passed' else 1)
