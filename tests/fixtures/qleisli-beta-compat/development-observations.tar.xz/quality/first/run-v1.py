from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path(__file__).parent;ql=Path('/Users/masa/git/Qleisli');root=Path('/Users/masa/git/qargo');sys.path.insert(0,str(ql/'scripts'))
from ci_source_checks import snapshot
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((base/'PLAN-v1.json').read_text());startfile=base/'started-v1.json';reportfile=base/'report-v1.json';assert not startfile.exists() and not reportfile.exists()
kernel=ql/'lean-kernel/.lake/build/bin/qleisli-kernel';before={'qargo':snapshot(root),'qleisli':snapshot(ql),'kernel_sha256':sha(kernel)};report={'plan_sha256':sha(base/'PLAN-v1.json'),'driver_sha256':sha(Path(__file__)),'before':before,'commands':[],'pid':os.getpid(),'pgid':os.getpgrp(),'scope':plan['scope']};startfile.write_text(json.dumps(report,indent=2)+'\n');start=time.monotonic()
try:
 for op in plan['operations']:
  directory=Path('/opt/homebrew/bin') if op['toolchain']=='normal' else Path('/Users/masa/.rustup/toolchains/1.85.0-aarch64-apple-darwin/bin');version='1.98.1' if op['toolchain']=='normal' else '1.85.0';tools={n:directory/n for n in ['cargo','rustc','rustdoc']};identities={n:{'path':str(p),'sha256':sha(p),'version':subprocess.check_output([str(p),'--version'],text=True).strip()} for n,p in tools.items()};assert all(v['version'].startswith(n+' '+version+' ') for n,v in identities.items())
  auxiliary=['rustfmt'] if op['label']=='normal-fmt' else ['cargo-clippy','clippy-driver'] if 'clippy' in op['label'] else []
  for n in auxiliary:
   p=directory/n;identities[n]={'path':str(p),'sha256':sha(p),'version':subprocess.check_output([str(p),'--version'],text=True).strip()}
  env=dict(os.environ)
  removed=['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']
  for n in removed:env.pop(n,None)
  env.update(RUSTC=str(tools['rustc']),RUSTDOC=str(tools['rustdoc']),RUSTUP_TOOLCHAIN=version,PATH=str(directory)+os.pathsep+os.environ.get('PATH',''),CARGO_TARGET_DIR=str(ql/'target'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',QLEISLI_KERNEL=str(kernel));env.update(op['extra_env']);argv=[str(tools['cargo']),'--config','patch.crates-io.qleisli.path="/Users/masa/git/Qleisli"',*op['cargo_args']];row=op|{'argv':argv,'tools':identities,'cleared_ambient_fields':removed,'environment':{n:env[n] for n in ['RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN','PATH','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','QLEISLI_KERNEL',*op['extra_env']]}};(base/(op['label']+'.started.json')).write_text(json.dumps(row,indent=2)+'\n');t=time.monotonic()
  with (base/(op['label']+'.stdout')).open('xb') as out,(base/(op['label']+'.stderr')).open('xb') as err:done=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=err)
  row.update(exit_code=done.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(base/(op['label']+'.stdout')),stderr_sha256=sha(base/(op['label']+'.stderr')));report['commands'].append(row);(base/(op['label']+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({n:row[n] for n in ['label','exit_code','seconds']}),flush=True)
except KeyboardInterrupt:report['interrupted']=True
finally:
 report.update(after={'qargo':snapshot(root),'qleisli':snapshot(ql),'kernel_sha256':sha(kernel)},seconds=time.monotonic()-start);report['stable']=report['before']==report['after'];report['status']='passed' if report['stable'] and len(report['commands'])==len(plan['operations']) and all(r['exit_code']==0 for r in report['commands']) else 'failed';reportfile.write_text(json.dumps(report,indent=2)+'\n')
print('REPORT '+str(reportfile),flush=True);raise SystemExit(0 if report['status']=='passed' else 1)
